<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class Susercontroller extends Controller
{
    public function tableau(){
        $soc = DB::table('users')->where('id','=', session('LoggedSUser'))->first(); 
        
        $utilisateurs = DB::table('users')
                                ->select('id','first_name','CIN','last_name','email','Tel')
                                ->where('society_id',$soc->society_id)
                                ->where('profile','User')
                                ->get();
        $themeusers=array();
        foreach($utilisateurs as $k=>$v){
            $themeusers[$v->id]=DB::table('user_themes')
                                ->join('themes','themes.id','=','user_themes.theme_id')
                                ->where('user_id',$v->id)
                                ->pluck('themes.name');
        }
        return view('Suser.Utilisateurs',compact('utilisateurs','themeusers')); 
    }
    public function edit(Request $request,$id){
        $rules = [
            /* 'Nomentreprise' => 'required|string|max:25', */
            'Nom' => 'required|string|max:25',
            'Prenom' => 'required|string|max:25',
            'Email'=> 'required|email|string',
            'Tel'=> 'required|numeric',
            'cin'=> 'required|max:10',
            'theme'=>'required',
        ];
    
        $customMessages = [
            'required' => 'Le champ :attribute est requis.',
            'email' => "L'email est incorrect.",
            'numeric' => "Entrez un numero de telephone valide.",
            "string" => "Vous devez entrer une chaîne de caractére.",
        ];
        $request->validate($rules, $customMessages);
        $delete=DB::table('user_themes')->where('user_id',$id)->delete();
        $insert=0;
        foreach($request->theme as $k=>$v){
            $insert+=DB::table('user_themes')->insert(['theme_id'=>$v,'user_id'=>$id]);
        }
        $update=DB::table('users')->where('id', $id)->update(['last_name'=>$request->Nom,'email' => $request->Email,'first_name'=>$request->Prenom,'Tel'=>$request->Tel,'CIN'=>$request->cin]);
        if($update or $delete and ($insert==count($request->theme))){
            $soc = DB::table('users')->where('id','=', session('LoggedSUser'))->first(); 
            $utilisateurs = DB::table('users')
                                    ->select('id','first_name','CIN','last_name','email','Tel')
                                    ->where('society_id',$soc->society_id)
                                    ->where('profile','User')
                                    ->get();
            $themeusers=array();
        foreach($utilisateurs as $k=>$v){
            $themeusers[$v->id]=DB::table('user_themes')
                                ->join('themes','themes.id','=','user_themes.theme_id')
                                ->where('user_id',$v->id)
                                ->pluck('themes.name');
        }
            $satustrue="L'utilisateur choisi est bien modifié";
            return view('Suser.Utilisateurs',compact('utilisateurs','themeusers','satustrue'));
        }
        else{
            $soc = DB::table('users')->where('id','=', session('LoggedSUser'))->first(); 
            $utilisateurs = DB::table('users')
                                    ->select('id','first_name','CIN','last_name','email','Tel')
                                    ->where('society_id',$soc->society_id)
                                    ->where('profile','User')
                                    ->get();
            $themeusers=array();
        foreach($utilisateurs as $k=>$v){
            $themeusers[$v->id]=DB::table('user_themes')
                                ->join('themes','themes.id','=','user_themes.theme_id')
                                ->where('user_id',$v->id)
                                ->pluck('themes.name');
        }
            $fail="Erreur! Réessayer la Modification";
            return view('Suser.Utilisateurs',compact('utilisateurs','themeusers','fail'));
        }    
        
    }
    public function add(Request $request){
        $rules = [
            /* 'Nomentreprise' => 'required|string|max:25', */
            'Nom' => 'required|string|max:25',
            'Prenom' => 'required|string|max:25',
            'Email'=> 'required|email|string',
            'Tel'=> 'required|numeric',
            'cin'=> 'required|max:10',
            'theme'=>'required',
        ];
    
        $customMessages = [
            'required' => 'Le champ :attribute est requis.',
            'email' => "L'email est incorrect.",
            'numeric' => "Entrez un numero de telephone valide.",
            "string" => "Vous devez entrer une chaîne de caractére.",
        ];
        $request->validate($rules, $customMessages);
        $soc = DB::table('users')->where('id','=', session('LoggedSUser'))->first();
        
        $id_user=DB::table('users')->insertGetId(['last_name'=>$request->Nom,'email' => $request->Email,'first_name'=>$request->Prenom,'Tel'=>$request->Tel,'CIN'=>$request->cin,'username'=> $request->Nom,'username_canonical'=> $request->Nom,
         'email_canonical'=> $request->Email,'enabled'=>1,'password'=>123456,'roles'=>'a:0:{}','profile'=>'User','society_id'=>$soc->society_id]);
        
        $insert=0;
        foreach($request->theme as $k=>$v){
            $insert+=DB::table('user_themes')->insert(['theme_id'=>$v,'user_id'=>$id_user]);
        }
       
        
        if( $id_user and ($insert==count($request->theme))){
  
            $satustrue=" Un Utilisateur est Ajouté";
            return view('Suser.Utilisateurs',compact('satustrue'));
        }
        else{

            $fail="Erreur! Réessayer l'Ajout";
            return view('Suser.Utilisateurs',compact('fail'));
        }    
        
    }
    public function delete(Request $request,$id){
        $delete_themes=DB::table('user_themes')->where('user_id',$id)->delete();
        $delete_users=DB::table('users')->where('id',$id)->delete();
        if( $delete_themes and $delete_users ){
            $satustrue="L'Utilisateur Choisi est Bien Supprimé";
            return view('Suser.Utilisateurs',compact('satustrue'));
        }
        else{
            
        }
            $fail="Erreur! Réessayer la Suppression";
            return view('Suser.Utilisateurs',compact('utilisateurs','themeusers','fail'));
        }   
        public function env()
    {
        $activity=DB::table('users_activities')->where('user_id',session('LoggedSUser'))->pluck('activity_id');
        
        $texts=DB::table('text')->where('theme_id',1)->whereIn('activity_id', $activity)->get();
        return view('Suser.texts',['texts'=>$texts]);
    }
    public function hsst()
    {
        
        $activity=DB::table('users_activities')->where('user_id',session('LoggedSUser'))->pluck('activity_id');
        $texts=DB::table('text')->where('theme_id',2)->whereIn('activity_id', $activity)->get();
        return view('Suser.texts',['texts'=>$texts]);
    }
    public function eng()
    {
        $activity=DB::table('users_activities')->where('user_id',session('LoggedSUser'))->pluck('activity_id');
        $texts=DB::table('text')->where('theme_id',3)->whereIn('activity_id', $activity)->get();
        return view('Suser.texts',['texts'=>$texts]);
    }
    public function qlt()
    {
        $activity=DB::table('users_activities')->where('user_id',session('LoggedSUser'))->pluck('activity_id');
        $texts=DB::table('text')->where('theme_id',4)->whereIn('activity_id', $activity)->get();
        return view('Suser.texts',['texts'=>$texts]);
    }
    public function fnc()
    {
        $activity=DB::table('users_activities')->where('user_id',session('LoggedSUser'))->pluck('activity_id');
        $texts=DB::table('text')->where('theme_id',5)->whereIn('activity_id', $activity)->get();
        return view('Suser.texts',['texts'=>$texts]);
    }
    public function fsq()
    {   
        $activity=DB::table('users_activities')->where('user_id',session('LoggedSUser'))->pluck('activity_id');
        $texts=DB::table('text')->where('theme_id',6)->whereIn('activity_id', $activity)->get();
        return view('Suser.texts',['texts'=>$texts]);
    } 
    public function lois($id)
    {   
        $rules=DB::table('rules')->where('text_id',$id)->pluck('content','id');
        $category = DB::table('category')
            ->join('text', 'category.id', '=', 'text.category_id')
            ->where('text.id',$id)
            ->value('category.name');
        $name = DB::table('text')->where('text.id',$id)->value('name');
        $description = DB::table('text')->where('text.id',$id)->value('description');
        $definition= DB::table('definitions')->where('text_id',$id)->get('content');
        $sanctions= DB::table('sanctions')->select('content')->where('text_id',$id)->get();
        $status=DB::table('rules')->where('text_id',$id)->pluck('status','id');
        return view('Suser.loi',['rules'=>$rules,'category'=>$category,'name'=>$name,'resume'=>$description,'sanctions'=>$sanctions,'definitions'=>$definition,'status'=>$status]);
    }
    public function conformite(Request $request){
       $array=array();
       foreach($request->request as $k=>$v){
             $array[$k]=$v;
       }
       unset($array["_token"]);
    foreach($array as $k=>$v){
        
        $update=DB::table('rules')->where('id', $k)->update(['status'=>$v]);
    }  
    return redirect()->back()->with('etat','Votre évaluation est enregistrée');
    }
    public function envactionplan()
    {
        $activity=DB::table('users_activities')->where('user_id',session('LoggedSUser'))->pluck('activity_id');
        
        $texts=DB::table('text')->where('theme_id',1)->whereIn('activity_id', $activity)->get();

        return view('Suser.actionplan',['texts'=>$texts]);
    }
    public function hsstactionplan()
    {
        
        $activity=DB::table('users_activities')->where('user_id',session('LoggedSUser'))->pluck('activity_id');
        $texts=DB::table('text')->where('theme_id',2)->whereIn('activity_id', $activity)->pluck('id','content');


        return view('Suser.actionplan',['texts'=>$texts]);
    }
    public function engactionplan()
    {
        $activity=DB::table('users_activities')->where('user_id',session('LoggedSUser'))->pluck('activity_id');
        $texts=DB::table('text')->where('theme_id',3)->whereIn('activity_id', $activity)->where('plan',0)->pluck('description','id');
         $rules=array();
         $texts_plan=DB::table('text')->join('plan','text.id',"=",'plan.text_id')->where('text.plan',1)->select('plan.id','plan.content','plan.title','plan.status','plan.user_id','plan.type','plan.criticality','plan.date','text.description')->get();
         
        foreach($texts as $k=>$v){
           $rules[$k]=DB::table('rules')->where('text_id',$k)->where('status',0)->pluck('content');
        }
        $exigences=array();
        foreach($rules as $k=>$v){
            $exigences[$k]=DB::table('rules')->where([['text_id',"=",$k],['status',"=",0]])->pluck('content');
         }
         $soc = DB::table('users')->where('id','=', session('LoggedSUser'))->value('society_id');
         
         
        $u=DB::table('users')->join('user_themes','users.id',"=","user_themes.user_id")->where('user_themes.theme_id',3)->where('users.society_id',$soc)->where('users.profile',"User")->select('users.last_name','users.first_name','users.id')->get();
        $user_name=DB::table('users')->join('plan','users.id',"=",'plan.user_id')->pluck('plan.user_id','plan.text_id');
         
        return view('Suser.actionplan',['texts'=>$texts,'exigences'=>$exigences,'usersth'=>$u,'texts_plan'=>$texts_plan]);
    }
    public function qltactionplan()
    {
        $activity=DB::table('users_activities')->where('user_id',session('LoggedSUser'))->pluck('activity_id');
        $texts=DB::table('text')->where('theme_id',4)->whereIn('activity_id', $activity)->get();
        return view('Suser.actionplan',['texts'=>$texts]);
    }
    public function fncactionplan()
    {
        $activity=DB::table('users_activities')->where('user_id',session('LoggedSUser'))->pluck('activity_id');
        $texts=DB::table('text')->where('theme_id',5)->whereIn('activity_id', $activity)->get();
        return view('Suser.actionplan',['texts'=>$texts]);
    }
    public function fsqactionplan()
    {   
        $activity=DB::table('users_activities')->where('user_id',session('LoggedSUser'))->pluck('activity_id');
        $texts=DB::table('text')->where('theme_id',6)->whereIn('activity_id', $activity)->get();
        return view('Suser.actionplan',['texts'=>$texts]);
    } 
    public function actionplan(Request $request,$text_id){
        $rules = [
            /* 'Nomentreprise' => 'required|string|max:25', */
            'title' => 'required|string|max:30',
            'description' => 'required|string',
            'type'=> 'required',
            'statut'=> 'required',
            'criticity'=> 'required',
            'user'=> 'required',
           /*  'date'=>'required|after:yesterday' */
        ];
    
        $customMessages = [
            'required' => 'le champ :attribute est requis.',
            "string" => "vous devez entrer une chaîne de caractére.",
           
        ];
        $request->validate($rules, $customMessages);
        $soc = DB::table('users')->where('id','=', session('LoggedSUser'))->value('society_id');
        $insert_plan=DB::table('plan')->insert([
            'title' => $request->title,
            'content' => $request->description,
            'user_id' => $request->user,
            'text_id' => $text_id,
            'type' => $request->type,
            'status' => $request->statut,
            'criticality' => $request->criticity,
            'date' => $request->date,
            'society_id' => $soc,
        ]);
        $insert_text=DB::table('text')->where('id',$text_id)->update([
            'plan' => 1]);

        
        $plan_infos=array('title'=>$request->title,'content' => $request->description,'type' => $request->type,
        'status' => $request->statut,'criticality' => $request->criticity,'date' => $request->date);
    
        
       return redirect()->back()->with('etat','enregistrement reussi');;
    }
        
    }


