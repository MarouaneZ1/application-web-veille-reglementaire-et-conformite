<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\users;
class Clientcontroller extends Controller
{

    //
    public function client()
    {
        return view('client.user');
    }
    public function env()
    {
        $activity=DB::table('users_activities')->where('user_id',session('Loggedclient'))->pluck('activity_id');
        $texts=DB::table('text')->where('theme_id',1)->whereIn('activity_id', $activity)->get();
        return view('client.texts',['texts'=>$texts]);
    }
    public function hsst()
    {
        
        $activity=DB::table('users_activities')->where('user_id',session('Loggedclient'))->pluck('activity_id');
        $texts=DB::table('text')->where('theme_id',2)->whereIn('activity_id', $activity)->get();
        return view('client.texts',['texts'=>$texts]);
    }
    public function eng()
    {
        $activity=DB::table('users_activities')->where('user_id',session('Loggedclient'))->pluck('activity_id');
        $texts=DB::table('text')->where('theme_id',3)->whereIn('activity_id', $activity)->get();
        return view('client.texts',['texts'=>$texts]);
    }
    public function qlt()
    {
        $activity=DB::table('users_activities')->where('user_id',session('Loggedclient'))->pluck('activity_id');
        $texts=DB::table('text')->where('theme_id',4)->whereIn('activity_id', $activity)->get();
        return view('client.texts',['texts'=>$texts]);
    }
    public function fnc()
    {
        $activity=DB::table('users_activities')->where('user_id',session('Loggedclient'))->pluck('activity_id');
        $texts=DB::table('text')->where('theme_id',5)->whereIn('activity_id', $activity)->get();
        return view('client.texts',['texts'=>$texts]);
    }
    public function fsq()
    {   
        $activity=DB::table('users_activities')->where('user_id',session('Loggedclient'))->pluck('activity_id');
        $texts=DB::table('text')->where('theme_id',6)->whereIn('activity_id', $activity)->get();
        return view('client.texts',['texts'=>$texts]);
    }
    public function lois($id)
    {   
        $rules=DB::table('rules')->where('text_id',$id)->pluck('content');
        $category = DB::table('category')
            ->join('text', 'category.id', '=', 'text.category_id')
            ->where('text.id',$id)
            ->value('category.name');
        $name = DB::table('text')->where('text.id',$id)->value('name');
        $description = DB::table('text')->where('text.id',$id)->value('description');
        $definition= DB::table('definitions')->where('text_id',$id)->get('content');
        
        $sanctions= DB::table('sanctions')->where('text_id',$id)->get('content');

        return view('client.loi',['rules'=>$rules,'category'=>$category,'name'=>$name,'resume'=>$description,'sanctions'=>$sanctions,'definitions'=>$definition]);
    }
}
