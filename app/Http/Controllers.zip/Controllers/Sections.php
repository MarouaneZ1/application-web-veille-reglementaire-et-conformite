<?php

namespace App\Http\Controllers;
use App\Models\users;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Sections extends Controller
{
    //
    public function sections(){
        $sections = DB::table('section')->get(); 
        $data = ['LoggedUserInfo'=>users::where('id','=', session('LoggedUser'))->first()];
        return  view('user_dashboard.sections.sections',['sections'=>$sections],$data); 
    }
    public function deletesections(Request $request,$id){
        DB::table('section')->where('id',$id)->delete();
        return redirect('/dashboard/secteursdactivites/sections');
    }
    public function updatesections(Request $request){
        $rules = [
           /* 'Nomentreprise' => 'required|string|max:25', */
           'Name' => 'required|string|max:25',
           'Code' => 'required|numeric|max:25',
       ];
   
       $customMessages = [
           'required' => 'le champ :attribute est requis.',
           'numeric' => "entrez un nombre.",
       ];

   
       /* $this->validate($request, $rules, $customMessages); */
       $request->validateWithBag('updateuser',$rules, $customMessages);
       $affected = DB::table('section')
              ->where('id',  $request->id)
              ->update(['code'=>$request->Code,'name' => $request->Name]);
       return redirect('/dashboard/secteursdactivites/sections');
    }
    public function addsections(Request $request){
        $rules = [
           /* 'Nomentreprise' => 'required|string|max:25', */
           'Names' => 'required|string|max:25|unique:section,id',
           'Codes' => 'required|numeric|max:25',
       ];
   
       $customMessages = [
           'required' => 'le champ :attribute est requis.',
           'numeric' => "entrez un nombre.",
           'unique'=>"la section existe deja",
           'string'=>"entrer une chaine de caractére"
       ];
       $attributes = [
        'Names' => 'Nom',
        'Codes' => 'Code'
       
    ]; 
   
       /* $this->validate($request, $rules, $customMessages); */
       $request->validateWithBag('adduser',$rules, $customMessages,$attributes);
       DB::table('section')->insert(['code'=>$request->Codes,'name' => $request->Names]);
       return redirect('/dashboard/secteursdactivites/sections');
    }
    public function branche(){
        $branches = DB::table('n1_activities')->get();
        $data = ['LoggedUserInfo'=>users::where('id','=', session('LoggedUser'))->first()];
        return view('user_dashboard.sections.branche',['branches'=>$branches],$data); 
    }
    public function deletebranche(Request $request,$id){
        DB::table('n1_activities')->where('id',$id)->delete();
        return redirect('/dashboard/secteursdactivites/branche');
    }
    public function updatebranche(Request $request){
        $rules = [
           /* 'Nomentreprise' => 'required|string|max:25', */
           'Name' => 'required|string|max:25',
           'Code' => 'required|numeric|max:25',
           'Nsection'=> 'required|numeric',
       ];
   
       $customMessages = [
           'required' => 'le champ :attribute est requis.',
           'numeric' => "entrez un nombre.",
       ];
   
       /* $this->validate($request, $rules, $customMessages); */
       $request->validateWithBag('updateuser',$rules, $customMessages);
       $affected = DB::table('n1_activities')
              ->where('id',  $request->id)
              ->update(['code'=>$request->Code,'name' => $request->Name,'section_id'=>$request->Nsection]);
       return redirect('/dashboard/secteursdactivites/branche');
    }
    public function addbranche(Request $request){
        $rules = [
           /* 'Nomentreprise' => 'required|string|max:25', */
           'Nameb' => 'required|string|max:25|unique:n1_activities,id',
           'Codeb' => 'required|numeric|max:25',
           'Nsectionb'=> 'required|numeric',
       ];
   
       $customMessages = [
           'required' => 'le champ :attribute est requis.',
           'numeric' => "entrez un nombre.",
           'string'=>"entrez une chaine de caractére.",
           'unique'=>"la branche existe deja"
       ];

       $attributes = [
        'Nameb' => 'Nom',
        'Codeb' => 'Code',
        'Nsectionb'=> 'N° Section ',
       
    ]; 
   
       /* $this->validate($request, $rules, $customMessages); */
       $request->validateWithBag('adduser',$rules, $customMessages,$attributes);
       DB::table('n1_activities')->insert(['code'=>$request->Codeb,'name' => $request->Nameb,'section_id'=>$request->Nsectionb]);
       return redirect('/dashboard/secteursdactivites/branche');
    }
    public function activities(){
        $activites = DB::table('activity')->get();
        $data = ['LoggedUserInfo'=>users::where('id','=', session('LoggedUser'))->first()];
        return view('user_dashboard.sections.activites',['activites'=>$activites],$data); 
    }
    public function deleteactivity(Request $request,$id){
        DB::table('activity')->where('id',$id)->delete();
        return redirect('/dashboard/secteursdactivites/activities');
    }
    public function updateactivity(Request $request){
        $rules = [
        'name' => 'required|string|max:70',
        'Code' => 'required|numeric',
        'n2activite'=> 'numeric',
        'n1activite'=> 'numeric',
        'nsection'=> 'numeric',
    ];

    $customMessages = [
        'required' => 'le champ :attribute est requis.',
        'numeric' => "Saisir un nombre",
        "string" => "vous devez entrer une chaîne de caractére.",
       
    ];

    /* $this->validate($request, $rules, $customMessages); */
    $request->validateWithBag('updateuser',$rules, $customMessages);
    $affected = DB::table('activity')
            ->where('id', $request->id)
            ->update(['name'=>$request->name,'code' => $request->Code,'n2_activity_id'=>$request->n2activite,'section_id'=>$request->nsection,'n1_activity_id'=>$request->n1activite]);
    return redirect('/dashboard/secteursdactivites/activities');
    }
    public function addactivity(Request $request){
        $rules = [
            'namea' => 'required|string|max:70|unique:activity,id',
            'Codea' => 'required|numeric',
            'n2activitea'=> 'numeric',
            'n1activitea'=> 'numeric',
            'nsectiona'=> 'numeric',
        ];
    
        $customMessages = [
            'required' => 'le champ :attribute est requis.',
            'numeric' => "Saisir un nombre",
            "string" => "vous devez entrer une chaîne de caractére.",
            "unique" => "l'activité existe déjà"
        ];
        $attributes = [
            'namea' => 'Nom',
            'Codea' => 'Code',
            'n2activitea' => 'Activité 2',
            'n1activitea' => 'Activité 1',
          'nsectiona' => 'N° Section '
        ]; 
       /* $this->validate($request, $rules, $customMessages); */
       $request->validateWithBag('adduser',$rules, $customMessages,$attributes);
       DB::table('activity')->insert([
        'name'=>$request->namea,
        'code' => $request->Codea,
        'enabled' => 1,
        'n2_activity_id'=>$request->n2activitea,
        'section_id'=>$request->nsectiona,
        'n1_activity_id'=>$request->n1activitea
        ]);
       return redirect('/dashboard/secteursdactivites/activities');
    }
    public function sousbranche(){
        $sousbranches =DB::table('n2_activities')->get();
        $data = ['LoggedUserInfo'=>users::where('id','=', session('LoggedUser'))->first()];
        return view('user_dashboard.sections.sousbranche',['sousbranches'=>$sousbranches],$data); 
    }
    public function deletesousbranche(Request $request,$id){
        DB::table('n2_activities')->where('id',$id)->delete();
        return redirect('/dashboard/secteursdactivites/sousbranche');
    }
    public function updatesousbranche(Request $request){
        $rules = [
           /* 'Nomentreprise' => 'required|string|max:25', */
           'Name' => 'required|string|max:25',
           'Code' => 'required|numeric|max:25',
           'Nsection'=> 'required|numeric',
           'Nbranche'=> 'required|numeric',
       ];
   
       $customMessages = [
           'required' => 'le champ :attribute est requis.',
           'numeric' => "entrez un nombre.",
       ];
   
       $request->validateWithBag('updateuser',$rules, $customMessages);
       $affected = DB::table('n2_activities')
              ->where('id',  $request->id)
              ->update(['code'=>$request->Code,'name' => $request->Name,'section_id'=>$request->Nsection,'n1_activity_id'=>$request->Nbranche]);
       return redirect('/dashboard/secteursdactivites/sousbranche');
    }
    public function addsousbranche(Request $request){
        $rules = [
           /* 'Nomentreprise' => 'required|string|max:25', */
           'Names' => 'required|string|max:25|unique:n2_activities,id',
           'Codes' => 'required|numeric|max:25',
           'Nsections'=> 'required|numeric',
           'Nbranches'=> 'required|numeric',
       ];
   
       $customMessages = [
           'required' => 'le champ :attribute est requis.',
           'numeric' => "entrez un nombre.",
           'unique' => "Sous branche existe deja.",

       ];
       $attributes = [
        'Names' => 'Nom',
        'Codes' => 'Code',
        'Nbranches' => 'Activité 1',
      'Nsections' => 'N° Section '
    ];
       /* $this->validate($request, $rules, $customMessages); */
       $request->validateWithBag('adduser',$rules, $customMessages,$attributes);
       DB::table('n2_activities')->insert(['code'=>$request->Codes,'name' => $request->Names,'section_id'=>$request->Nsections,'n1_activity_id'=>$request->Nbranches]);
       return redirect('/dashboard/secteursdactivites/sousbranche');
    }
    
    
    
}
