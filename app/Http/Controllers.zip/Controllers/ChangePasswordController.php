<?php
namespace App\Http\Controllers;
use App\Models\users;
use Illuminate\Http\Request;
use App\Rules\MatchOldPassword;
use Illuminate\Support\Facades\Hash;
use App\User;
  
class ChangePasswordController extends Controller
{

    public function store(Request $request)
    {
        $request->validate([
            'current_password' => ['required', new MatchOldPassword],
            'new_password' => ['required','same:password_confirmation'],
            'password_confirmation' => ['required'],
        ]);
        users::find(users::where('id','=', session('LoggedUser'))->select('id')->first()['id'])->update(['password'=> Hash::make($request->new_password)]);
        return ('Password change successfully.');
    }
}