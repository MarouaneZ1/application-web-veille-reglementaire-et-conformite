<?php

namespace App\Http\Controllers;
use App\Models\users;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class Textereglementaire extends Controller
{
    //
    public function BO(){
        $BOS = DB::table('bos')->get();
        $data = ['LoggedUserInfo'=>users::where('id','=', session('LoggedUser'))->first()];
        return view('user_dashboard.Texte_reglementaire.BO',['BOs'=>$BOS],$data); 
    }
    public function add_BO(Request $request){
        $rules = [
            'name' => 'required|string|max:25',
            'Date' => 'required|string|max:25',
            'File'=> 'required',
            'JoursArabe'=> 'required|max:15',
            'MoisArabe' => 'required|string|max:25',
            'Annesarabe' => 'required|string|max:25',
        ];
        $customMessages = [
            'required' => 'le champ :attribute est requis.',
            'email' => "l'email est incorrect.",
            'numeric' => "le numero de telephone n'est pas un numérique.",
            "string" => "vous devez entrer une chaîne de caractére.",
            "unique" => "l'email existe deja."
        ];
        $attributes=[
            'JoursArabe'=> 'Jour en arabe',
            'MoisArabe' => 'Mois en arabe',
            'Annesarabe' => 'Année en arabe',
        ];
        /* $this->validate($request, $rules, $customMessages); */
        $request->validateWithBag('adduser',$rules, $customMessages,$attributes);
        DB::table('bos')->insert([
         'name' => $request->name,
         'date'=> $request->Date,
         'file' => $request->File,
         'day_arabe'=> $request->JoursArabe,
         'mount_arabe'=> $request->MoisArabe,
         'year_arabe'=> $request->Annesarabe,
         ]);
        return redirect('/dashboard/TexteReglementaire/BO');
    }
    public function deleteBO(Request $request,$id){
        DB::table('bos')->where('id',$id)->delete();
        return redirect('/dashboard/TexteReglementaire/BO');
    }
    public function updateBO(Request $request){
        $rules = [
            'nameu' => 'required|string|max:25',
            'Dateu' => 'required|string|max:25',
            'Fileu'=> 'required',
            'JoursArabeu'=> 'required|max:15',
            'MoisArabeu' => 'required|string|max:25',
            'Annesarabeu' => 'required|string|max:25',
        ];
        $customMessages = [
            'required' => 'le champ :attribute est requis.',
            'email' => "l'email est incorrect.",
            'numeric' => "le numero de telephone n'est pas un numérique.",
            "string" => "vous devez entrer une chaîne de caractére.",
            "unique" => "l'email existe deja."
        ];
        $attributes=[
            'nameu' => 'Nom',
            'Dateu' => 'Date',
            'Fileu'=> 'Fichier',
            'JoursArabeu'=> 'Jour en arabe',
            'MoisArabeu' => 'Mois en arabe',
            'Annesarabeu' => 'Année en arabe',
        ];
           /* $this->validate($request, $rules, $customMessages); */
           $request->validateWithBag('updateuser',$rules, $customMessages,$attributes);
       $affected = DB::table('bos')
              ->where('id', $request->id)
              ->update([
                'name' => $request->nameu,
                'date'=> $request->Dateu,
                'file' => $request->Fileu,
                'day_arabe'=> $request->JoursArabeu,
                'mount_arabe'=> $request->MoisArabeu,
                'year_arabe'=> $request->Annesarabeu,
                ]);
       return redirect('/dashboard/TexteReglementaire/BO');
    }
    public function texts(){

        $texts = DB::table('text')->select('id', 'category_id', 'bo_id', 'name', 'description', 'date')->get(); 
       // return  view('user_dashboard.utilisateurs.tableau',['region'=>$user_info]); 
       $data = ['LoggedUserInfo'=>users::where('id','=', session('LoggedUser'))->first()];
    foreach($texts as $k=>$v){
       $categorie_name=DB::table('category')->where('id',$v->category_id)->value('name'); 
       $texts[$k]->category_id=$categorie_name;  
    }
        return view('user_dashboard.Texte_reglementaire.texts',['texts'=>$texts],$data);
    }
    public function delete_text(Request $request,$id){
        DB::table('text')->where('id',$id)->delete();
        return redirect('/dashboard/TexteReglementaire/texts');
    }
            
public function update_text(Request $request){
        $rules = [
           /* 'Nomentreprise' => 'required|string|max:25', */
           'catu' => 'required|string|max:25',
           'BOu' => 'required|string|max:25',
           'Nomu' => 'required|string|max:25',
           'descriptionu' => 'required|string|max:25',
           'dateu' => 'required|string|max:25',
       ];
   
       $customMessages = [
           'required' => 'le champ :attribute est requis.',
           'email' => "l'email est incorrect.",
           'numeric' => "le numero de telephone n'est pas un numérique.",
           "string" => "vous devez entrer une chaîne de caractére.",
           "unique" => "l'email existe deja."
       ];
       $attributes=[
        /* 'Nomentreprise' => 'required|string|max:25', */
        'catu' => 'Catégorie',
        'BOu' => 'Bultin officiel',
        'Nomu' => 'Nom',
        'descriptionu' => 'Description',
        'dateu' => 'Date',
    ];
       /* $this->validate($request, $rules, $customMessages); */
       $request->validateWithBag('updateuser',$rules, $customMessages,$attributes);
       $affected = DB::table('text')
              ->where('id', $request->id)
              ->update(['category_id'=>$request->catu,'bo_id' => $request->BOu,'name' => $request->Nomu,'description' => $request->descriptionu,'date' => $request->dateu]);
       return redirect('/dashboard/TexteReglementaire/texts');
    }

    public function add_text(Request $request){
        $rules = [
            /* 'Nomentreprise' => 'required|string|max:25', */
            'cat' => 'required|string|max:25',
            'BO' => 'required',
            'Nom'=> 'required|string|max:25',
            'description'=> 'required|max:15',
            'date'=> 'required|max:15'
        ];
     
        $customMessages = [
            'required' => 'le champ :attribute est requis.',
            'email' => "l'email est incorrect.",
            'numeric' => "le numero de telephone n'est pas un numérique.",
            "string" => "vous devez entrer une chaîne de caractére.",
            "unique" => "l'email existe deja."
        ];
        $attributes=[
            /* 'Nomentreprise' => 'required|string|max:25', */
            'cat' => 'Catégorie',
            'BO' => 'Bultin officiel',
            'Nom' => 'Nom',
            'description' => 'Description',
            'date' => 'Date',
        ];
        /* $this->validate($request, $rules, $customMessages); */
        $request->validateWithBag('adduser',$rules, $customMessages,$attributes);
        DB::table('text')->insert([
         'category_id' => $request->cat,
         'bo_id'=> $request->BO,
         'name' => $request->Nom,
         'description'=> $request->description,
         'date'=> $request->date,
         'state'=> 1,
         'createdAt'=>'2020-11-07',
         'updateAt'=>'2020-11-07'
         ]);
        return redirect('/dashboard/TexteReglementaire/texts');
    }
    public function rules(){
        $rules = DB::table('rules')->get(); 
        $data = ['LoggedUserInfo'=>users::where('id','=', session('LoggedUser'))->first()];
        return  view('user_dashboard.Texte_reglementaire.rules',['rules'=>$rules],$data); 
    }
    public function deleterule(Request $request,$id){
        DB::table('rules')->where('id',$id)->delete();
        return redirect('/dashboard/TexteReglementaire/rules');
    }
    public function updaterule(Request $request){
        $rules = [
           'text_idu' => 'required|numeric',
           'contentu' => 'required|string',
           'avisu'=> 'required|string|max:30',
           'referenceu'=> 'required|string|max:30',
           

       ];
   
       $customMessages = [
           'required' => 'le champ :attribute est requis.',
           'email' => "l'email est incorrect.",
           'numeric' => "le champ  doit etre numérique.",
           "string" => "vous devez entrer une chaîne de caractére.",
           "unique" => "l'éxigence existe deja."
       ];
   
       $attributes=[
        /* 'Nomentreprise' => 'required|string|max:25', */
        'text_id' => 'text',
        'contentu' => 'content',
        'avisu'=> 'avis',
        'referenceu'=> 'reference',
    ];
       /* $this->validate($request, $rules, $customMessages); */
       $request->validateWithBag('updateuser',$rules, $customMessages,$attributes);
       $affected = DB::table('rules')
              ->where('id', $request->id)
              ->update(['text_id'=>$request->text_idu,'content' => $request->contentu,'avis'=>$request->avisu,'reference'=>$request->referenceu]);
       return redirect('/dashboard/TexteReglementaire/rules');
    }
    public function addrule(Request $request){
        $rules = [ 
            'text_id' => 'required|numeric|exists:text,id',
            'content' => 'required|string',
            'avis'=> 'required|string|max:30',
            'reference'=> 'required|string|max:30',
            
 
        ];
    
        $customMessages = [
            'required' => 'le champ :attribute est requis.',
            'email' => "l'email est incorrect.",
            'numeric' => "le champ  doit etre numérique.",
            "string" => "vous devez entrer une chaîne de caractére.",
            "unique" => "l'éxigence existe deja.",
            "exists"=>"il faut entrer un id qui existe deja"
        ];
        $attributes=[
            /* 'Nomentreprise' => 'required|string|max:25', */
            'text_id' => 'text'
        ];
        /* $this->validate($request, $rules, $customMessages); */
        $request->validateWithBag('adduser',$rules, $customMessages,$attributes);
       DB::table('rules')->insert([
        'text_id'=>$request->text_id,'content' => $request->content,'avis'=>$request->avis,'reference'=>$request->reference,'createdAt'=>'2017-09-07','updateAt'=>'2017-09-07','status'=>'online'
        ]);
       return redirect('/dashboard/TexteReglementaire/rules');
    }
}
