<?php

namespace App\Http\Controllers;
use App\Models\users;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class Utilisateurs extends Controller
{
    public function tableau(){
        $user_info = DB::table('users')->select('id','first_name','last_name','email','profile','CIN')->get();
        $data = ['LoggedUserInfo'=>users::where('id','=', session('LoggedUser'))->first()]; 
        return  view('user_dashboard.utilisateurs.tableau',['users'=>$user_info],$data); 
    }
    public function Userdetail($id){
        $data=DB::table('bos')->where('id', $id)->get();
        return $data; 
    }
    public function deleteuser(Request $request,$id){
        DB::table('user_themes')->where('user_id',$id)->delete();
        DB::table('users_activities')->where('user_id',$id)->delete();
        DB::table('users')->where('id',$id)->delete();
        return redirect('/dashboard/utilisateurs/tableau');
    }
    public function updateuser(Request $request){
        $rules = [
           /* 'Nomentreprise' => 'required|string|max:25', */
           'Nom' => 'required|string|max:25',
           'Prenom' => 'required|string|max:25',
           'Email'=> 'required|email|string',
           'Profile'=> 'required|max:15',
           'cin'=>'required|max:10'
       ];
   
       $customMessages = [
           'required' => 'le champ :attribute est requis.',
           'email' => "l'email est incorrect.",
           'numeric' => "le numero de telephone n'est pas un numérique.",
           "string" => "vous devez entrer une chaîne de caractére.",
           "unique" => "l'email existe deja."
       ];
      $attributes=[
          'cin'=>'CIN'
      ];
   
       /* $this->validate($request, $rules, $customMessages); */
       $request->validateWithBag('updateuser',$rules, $customMessages,$attributes);
       $affected = DB::table('users')
              ->where('id', $request->id)
              ->update(['last_name'=>$request->Nom,'email' => $request->Email,'first_name'=>$request->Prenom,'profile'=>$request->Profile,'CIN'=>$request->cin]);
       return redirect('/dashboard/utilisateurs/tableau');
    }
    public function activite(){
        $users = DB::table('users')
            ->join('users_activities', 'users.id', '=', 'users_activities.user_id')
            ->join('activity', 'activity.id', '=', 'users_activities.activity_id')
            ->select('users.first_name', 'users.last_name', 'users.id','activity.name')
            ->get();
            $data = ['LoggedUserInfo'=>users::where('id','=', session('LoggedUser'))->first()];
        return view('user_dashboard.utilisateurs.activites',['users'=>$users],$data);
 
    }
    public function adduser(Request $request){
        $rules = [
           /* 'Nomentreprise' => 'required|string|max:25', */
           'Nomu' => 'required|string|max:25',
           'Prenomu' => 'required|string|max:25',
           'Emailu'=> 'required|email|string|unique:users,email',
           'Profileu'=> 'required|max:15',
           'cin'=>'required|max:10'
       ];
   
       $customMessages = [
           'required' => 'le champ :attribute est requis.',
           'email' => "l'email est incorrect.",
           'numeric' => "le numero de telephone n'est pas un numérique.",
           "string" => "vous devez entrer une chaîne de caractére.",
           "unique" => "l'email existe deja."
       ];
       $attributes = [
        'Nomu' => 'Nom','Prenomu' => 'Prenom','Emailu' => 'Email','Profileu' => 'Profile','cin'=>'CIN'
    ];
       /* $this->validate($request, $rules, $customMessages); */
       $request->validateWithBag('adduser',$rules, $customMessages,$attributes);
       DB::table('users')->insert([
        'email' => $request->Emailu,
        'first_name'=> $request->Nomu,
        'last_name' => $request->Prenomu,
        'username'=> $request->Nomu,
        'CIN'=>$request->cin,
        'username_canonical'=> $request->Nomu,
        'email_canonical'=> $request->Emailu,
        'enabled'=>1,
        'password'=>123456,
        'roles'=>'a:0:{}',
        'profile'=>$request->Profileu
        ]);
       return redirect('/dashboard/utilisateurs/tableau');
    }
    public function theme(){
        $users = DB::table('users')
            ->join('user_themes', 'users.id', '=', 'user_themes.user_id')
            ->join('themes', 'themes.id', '=', 'user_themes.theme_id')
            ->select('users.first_name', 'users.last_name', 'users.id','themes.name')
            ->get();
            $data = ['LoggedUserInfo'=>users::where('id','=', session('LoggedUser'))->first()];
        return view('user_dashboard.utilisateurs.theme',['users'=>$users],$data);
 
    }
    /* SELECT `name` FROM `activity` WHERE id IN(SELECT `activity_id` FROM `users_activities` WHERE `user_id`=2) 
    SELECT name,users_activities.activity_id FROM `users_activities`,activity WHERE users_activities.activity_id=activity.id AND user_id=3
    */
    public function societies(){
        $societies = DB::table('societies')->get(); 
        $data = ['LoggedUserInfo'=>users::where('id','=', session('LoggedUser'))->first()];
        return  view('user_dashboard.utilisateurs.societies',['societies'=>$societies],$data); 
    }
    public function deletesociety(Request $request,$id){
        DB::table('societies')->where('id',$id)->delete();
        return redirect('/dashboard/utilisateurs/societies');
    }

    public function updatesociety(Request $request){
        $rules = [ 
           'nameu' => 'required|string|max:30',
           'adresseu' => 'required|string|max:60',
           'telu'=> 'required|string',
           'faxu'=> 'required|string|max:15',
           'contact_nameu'=> 'required|string|max:25',
           'contact_telu'=> 'required|string',
           'contact_mailu'=> 'required|email',
           'ice' => 'required|string|max:15',
           'idf' => 'required|string|max:20',
           'rc' => 'required|string|max:20',
           'cnss' => 'required|string|max:20',
       'Npatente'=>'required|numeric',

       ];
   
       $customMessages = [
           'required' => 'le champ :attribute est requis.',
           'email' => "l'email est incorrect.",
           'numeric' => "le numero de telephone n'est pas un numérique.",
           "string" => "vous devez entrer une chaîne de caractére.",
           "unique" => "la société existe deja."
       ];
       $attributes = [
        'nameu' => 'Nom',
           'adresseu' => 'Adresse',
           'telu'=> 'Tel',
           'faxu'=> 'Fax',
           'contact_nameu'=> 'Nom Contact',
           'contact_telu'=> 'Tel Contact',
           'contact_mailu'=> 'Mail Contact',
            'Npatente'=>'N° Patente',
            'cin'=>'CIN',
            'ice'=>'ICE',
            'idf'=>'IF',
            'rc'=>'RC',
            'cnss'=>'CNSS'
    ];
   
       /* $this->validate($request, $rules, $customMessages); */
       $request->validateWithBag('updateuser',$rules, $customMessages,$attributes);
       $affected = DB::table('societies')
              ->where('id', $request->id)
              ->update(['name'=>$request->nameu,'adresse' => $request->adresseu,'tel'=>$request->telu,'fax'=>$request->faxu,'contact_name'=>$request->contact_nameu,'contact_tel'=>$request->contact_telu,'contact_mail'=>$request->contact_mailu,
              'patente'=>$request->Npatente,
                'ICE'=>$request->ice,
                'RC'=>$request->rc,
                'IDF'=>$request->idf,
                'CNSS'=>$request->cnss]);
       return redirect('/dashboard/utilisateurs/societies');
    }
    public function addsociety(Request $request){
        $rules = [
            'name' => 'required|string|max:30',
            'adresse' => 'required|string|max:60',
            'tel'=> 'required|string',
            'fax'=> 'required|string|max:15',
            'contact_name'=> 'required|string|max:25',
            'contact_tel'=> 'required|string',
            'contact_mail'=> 'required|email',
            'ice' => 'required|string|max:15',
            'idf' => 'required|string|max:20',
            'rc' => 'required|string|max:20',
            'cnss' => 'required|string|max:20',
            'Npatente'=>'required|numeric',
 
        ];
    
        $customMessages = [
            'required' => 'le champ :attribute est requis.',
            'email' => "l'email est incorrect.",
            'numeric' => "le numero de telephone n'est pas un numérique.",
            "string" => "vous devez entrer une chaîne de caractére.",
            "unique" => "la société existe deja."
        ];
        $attributes = [
                'Npatente'=>'N° Patente',
                'cin'=>'CIN',
                'ice'=>'ICE',
                'idf'=>'IF',
                'rc'=>'RC',
                'cnss'=>'CNSS'
        ];

    
       /* $this->validate($request, $rules, $customMessages); */
       $request->validateWithBag('adduser',$rules, $customMessages,$attributes);
       DB::table('societies')->insert([
        'name'=>$request->name,'adresse' => $request->adresse,'tel'=>$request->tel,'fax'=>$request->fax,'contact_name'=>$request->contact_name,'contact_tel'=>$request->contact_tel,'contact_mail'=>$request->contact_mail,'patente'=>$request->Npatente,
        'ICE'=>$request->ice,
        'RC'=>$request->rc,
        'IDF'=>$request->idf,
        'CNSS'=>$request->cnss
        ]);
       return redirect('/dashboard/utilisateurs/societies');
    }
}
